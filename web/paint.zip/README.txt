--- The rom requires the following ---
The clock running in centiseconds (realtime)
Looping memory
The network card
The GPU
The DPAD
External Memory
A serial terminal

The screen should not be cleared ever,
and should start out black,
and should update on every draw

--- Server: emu-1.quphoria.co.uk:1337 ---
The gallery is at https://emu-1.quphoria.co.uk/
